﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

namespace Milons_OS_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MySequence1 ms = new MySequence1(1, richTextBox1);
                WaitCallback wcb = new WaitCallback(ms.start); //Delegate object
                ThreadPool.QueueUserWorkItem(wcb);

                //Delegate class : WaitCallback
                //Delefate object : wcb
                //a delegateobject carries a function: ms.start

                //start a thread:  ThreadPool.QueueUserWorkItem();
            }
            catch ( Exception ex)
            {
                richTextBox1.AppendText(ex.ToString());
            }
        }
    }
}
