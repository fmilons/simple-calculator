package com.csci4020kexample.simplecalcultor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import org.mariuszgromada.math.mxparser.*
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.view.View
import android.webkit.WebView
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private lateinit var display :EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        display = findViewById(R.id.input)
        display.showSoftInputOnFocus = false
    }
    //method to update the text
    private fun updateText(strToAdd: String) {
        var oldString:String = display.text.toString()
        var currentPos:Int = display.selectionStart
        var leftStr:String = oldString.substring(0,currentPos)
        var rightStr:String = oldString.substring(currentPos)
        if(getString(R.string.display) == display.text.toString()) {
            display.setText(strToAdd)
            display.setSelection(currentPos+1)

        }
        else{
            display.setText(String.format("%s%s%s",leftStr, strToAdd, rightStr))
            display.setSelection(currentPos + 1)
        }

    }
    //implementing methods for all buttons
    fun zeroBtn(view:View){
        if(getString(R.string.display)== display.text.toString()){
            display.setText("0")
            }
            else {
                updateText(strToAdd = "0")
        }
    }
    fun oneBtn(view: View){
        updateText(strToAdd = "1")
    }
    fun twoBtn(view: View){
        updateText(strToAdd = "2")
    }
    fun threeBtn(view: View) {
        updateText(strToAdd = "3")
    }
    fun fourBtn(view: View) {
        updateText(strToAdd = "4")
    }
    fun fiveBtn(view: View) {
        updateText(strToAdd = "5")
    }
    fun sixBtn(view: View) {
        updateText(strToAdd = "6")
    }
    fun sevenBtn(view: View) {
        updateText(strToAdd = "7")
    }
    fun eightBtn(view: View) {
        updateText(strToAdd = "8")
    }
    fun nineBtn(view: View) {
        updateText(strToAdd = "9")
    }
    fun clearBtn(view: View){
        display.setText("")
    }
    fun exponentBtn(view: View){
        updateText(strToAdd = "^")
    }
    fun divideBtn(view: View){
        updateText(strToAdd = "÷")
    }
    fun multiplyBtn(view: View){
        updateText(strToAdd = "×")
    }
    fun subtractBtn(view: View){
        updateText(strToAdd = "-")
    }
    fun addBtn(view: View){
        updateText(strToAdd = "+")
    }
    fun plusMinusBtn(view: View) {
        var oldStr: String = display.text.toString()
        var currentPos: Int = display.selectionStart
        var leftStr: String = oldStr.substring(0, currentPos)
        var rightStr: String = oldStr.substring(currentPos)


        if(display.text.startsWith( "-")) {
                display.setText(oldStr.substring(1, currentPos))
                display.setSelection(currentPos - 1)
        }
        else if(getString(R.string.display) == display.text.toString()){
            display.setText("0")
        }
        else if(display.text.isNotEmpty() && !display.text.equals("0")){
                    display.setText(String.format("%S%S%S", "-", leftStr, rightStr))
            display.setSelection((currentPos+1))


            }


    }
    fun pointBtn(view: View){
        updateText(strToAdd = ".")
    }
    fun equalsBtn(view: View){
        var userExp = display.text.toString()
        userExp = userExp.replace("÷".toRegex(),"/")
        userExp = userExp.replace("×".toRegex(), "*")
        userExp = userExp.replace("%".toRegex(), "#")
        val exp = Expression(userExp)
        val result = exp.calculate().toString()
        updateText(strToAdd = "=")
        display.setText(result)
        display.setSelection(result.length)
    }
    fun backspaceBtn(view: View) {
        var cursorPos: Int = display.selectionStart
        var textLength: Int = display.text.length

        if (cursorPos != 0 && textLength != 0) {
            display.text =
                SpannableStringBuilder(display.text).replace(cursorPos - 1, cursorPos, "")
            display.setSelection(cursorPos - 1)
        }
    }
    fun parenthesesBtn(view: View){
            var cursorPos: Int = display.selectionStart
            var openPar: Int = 0
            var closePar: Int = 0
            var textLength: Int = display.text.length
            for(i in 0 until cursorPos){
                if(display.text.toString().substring(i, i + 1) == "(") {
                    openPar += 1
                }
                if(display.text.toString().substring(i, i + 1) == "(") {
                    closePar += 1
                }
            }
            if(openPar == closePar || display.text.toString().substring(textLength -1, textLength) == "("){
                updateText(strToAdd = "(")
            }
            if(closePar < openPar && display.text.toString().substring(textLength -1, textLength) != "("){
                updateText(strToAdd = ")")
            }
            display.setSelection(cursorPos + 1)
        }
    fun tanBtn(view: View) {
        updateText(strToAdd = "tan")
    }
    fun sinBtn(view: View){
        updateText(strToAdd = "sin")
    }
    fun cosBtn(view: View) {
        updateText(strToAdd = "cos")
    }
    fun sin_1Btn(view: View) {
        updateText(strToAdd = "arcsin")
    }
    fun cos_1Btn(view: View){
        updateText(strToAdd = "arcos")
    }
    fun tan_1Btn(view: View){
        updateText(strToAdd = "artan")
    }
    fun logBtn(view: View) {
        updateText(strToAdd = "log(")
    }
    fun lnBtn(view: View) {
        updateText(strToAdd = "ln(")
    }
    fun sqrtBtn (view: View) {
        updateText(strToAdd = "sqrt(")
    }
    fun e_constantBtn(view: View) {
        updateText(strToAdd = "e")
    }
    fun piBtn(view: View) {
        updateText(strToAdd = "pi")
    }
    fun absBtn(view: View) {
        updateText(strToAdd = "abs")
    }
    fun modulusBtn(view: View) {
        updateText(strToAdd = "%")
    }
    fun expBtn(view: View) {
        updateText(strToAdd = "^(2)")
    }
    fun exp_yBtn(view: View) {
        updateText(strToAdd = "^(")
    }

    }
